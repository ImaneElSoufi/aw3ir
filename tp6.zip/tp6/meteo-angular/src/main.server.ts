export { AppServerModule as default } from './app/app.module.server';
