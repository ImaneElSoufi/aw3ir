// src\app\meteoItem.ts
export class MeteoItem {
    id?: number;
    name?: string;
    weather: any;
  }